#ifndef common
#define common
extern int ownerId;
extern int runnerId;
extern struct config_struct *config;
extern char *configPath;
extern char *fileListPath;
extern char *filesPath;
extern struct file_list *fileList;
#endif
